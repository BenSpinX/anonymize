DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_ACRQA_1.0 BLOCK1",
"0023xx00":"CR Exposure Menu Code",
"0023xx10":"CR Exposure Menu String",
"0023xx20":"CR EDR Mode",
"0023xx30":"CR Latitude",
"0023xx40":"CR Group Number",
"0023xx50":"CR Image Serial Number",
"0023xx60":"CR Bar Code Number",
"0023xx70":"CR Film Output Exposure",
"0023xx80":"CR Film Format",
"0023xx90":"CR S Shift String"
});
