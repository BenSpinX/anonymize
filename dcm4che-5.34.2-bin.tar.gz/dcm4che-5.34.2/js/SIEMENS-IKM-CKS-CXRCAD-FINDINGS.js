DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS IKM CKS CXRCAD FINDINGS",
"0029xx01":"?"
});
