DCM4CHE.elementName.addDictionary({
"privateCreator":"Siemens: Thorax/Multix FD Version",
"0017xx00":"?",
"0017xx01":"?"
});
