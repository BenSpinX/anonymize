DCM4CHE.elementName.addDictionary({
"privateCreator":"CARDIO-D.R. 1.0",
"0029xx00":"Edge Enhancement Sequence",
"0029xx01":"Convolution Kernel Size",
"0029xx02":"Convolution Kernel Coefficients",
"0029xx03":"Edge Enhancement Gain",
"0029xxAC":"Displayed Area Bottom Right Hand Corner Fractional",
"0029xxAD":"Displayed Area Top Left Hand Corner Fractional"
});
