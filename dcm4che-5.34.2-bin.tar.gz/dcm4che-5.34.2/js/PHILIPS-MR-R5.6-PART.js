DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS MR R5.6/PART",
"0019xx00":"Field of View"
});
