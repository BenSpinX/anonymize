DCM4CHE.elementName.addDictionary({
"privateCreator":"AGFA KOSD 1.0",
"0035xx00":"?",
"0035xx03":"?"
});
