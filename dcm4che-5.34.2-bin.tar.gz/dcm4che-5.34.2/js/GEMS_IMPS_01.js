DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_IMPS_01",
"0029xx04":"Lower Range Of Pixels",
"0029xx15":"Lower Range Of Pixels1",
"0029xx16":"Upper Range Of Pixels1",
"0029xx17":"Lower Range Of Pixels2",
"0029xx18":"Upper Range Of Pixels2",
"0029xx1A":"Length Of Total Header In Bytes",
"0029xx26":"Version Of Header Structure",
"0029xx34":"Advantage Comp Overflow",
"0029xx35":"Advantage Comp Underflow"
});
