DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED DISPLAY 0000",
"0029xx99":"?",
"0029xxC1":"?",
"0029xxB0":"?",
"0029xxB2":"?"
});
