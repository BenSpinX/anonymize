DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CSA NON-IMAGE",
"0029xx08":"CSA Data Type",
"0029xx09":"CSA Data Version",
"0029xx10":"CSA Data Info",
"7FE1xx10":"CSA Data"
});
