DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS Selma",
"0019xx06":"?",
"0019xx07":"?",
"0019xx08":"?",
"0019xx26":"?",
"0019xx29":"?",
"0019xx30":"?",
"0019xx31":"?",
"0019xx32":"?",
"0019xx33":"?",
"0019xx34":"?",
"0019xx35":"?"
});
