DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS Ultrasound S2000",
"0021xx00":"Nipple Position",
"0021xx01":"ABVS Clip Derived From Volume"
});
