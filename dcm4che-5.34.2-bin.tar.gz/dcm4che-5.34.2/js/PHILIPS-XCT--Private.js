DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS XCT -Private",
"7051xx01":"Attenuation Threshold",
"7051xx02":"DLPEstimate"
});
