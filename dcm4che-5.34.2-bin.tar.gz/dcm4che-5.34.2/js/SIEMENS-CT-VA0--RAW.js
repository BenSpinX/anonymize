DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT VA0  RAW",
"0021xx10":"Creation Mask",
"0021xx20":"Evaluation Mask",
"0021xx30":"Extended Processing Mask",
"0021xx40":"?",
"0021xx41":"?",
"0021xx42":"?",
"0021xx43":"?",
"0021xx44":"?",
"0021xx50":"?"
});
