DCM4CHE.elementName.addDictionary({
"privateCreator":"http://www.gemedicalsystems.com/it_solutions/orthoview/2.1",
"3117xx10":"OrthoView Session Date/Time",
"3117xx20":"OrthoView Session Creator",
"3117xx30":"OrthoView Session Completion Flag",
"3117xx40":"OrthoView File Sequence",
"3117xx50":"OrthoView File Name",
"3117xx60":"OrthoView File Content"
});
