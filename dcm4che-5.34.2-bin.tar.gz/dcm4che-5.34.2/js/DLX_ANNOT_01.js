DCM4CHE.elementName.addDictionary({
"privateCreator":"DLX_ANNOT_01",
"70XXxx04":"TextAnnotation",
"70XXxx05":"Box",
"70XXxx07":"ArrowEnd"
});
