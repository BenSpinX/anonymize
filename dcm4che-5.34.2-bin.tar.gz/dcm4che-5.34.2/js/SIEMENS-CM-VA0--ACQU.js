DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CM VA0  ACQU",
"0019xx10":"Parameter File Name",
"0019xx11":"Sequence File Name",
"0019xx12":"Sequence File Owner",
"0019xx13":"Sequence Description",
"0019xx14":"EPI File Name"
});
