DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_Ultrasound_ExamGroup_001",
"6005xx10":"?",
"6005xx20":"?"
});
