DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private-CWS Release 1",
"0021xx00":"Window Of Images ID",
"0021xx01":"Window Of Images Type",
"0021xx02":"WindowOfImagesScope"
});
