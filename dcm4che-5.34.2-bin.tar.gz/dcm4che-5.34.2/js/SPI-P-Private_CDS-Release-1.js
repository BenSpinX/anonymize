DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-Private_CDS Release 1",
"0021xx40":"?",
"0029xx00":"?",
"0029xx10":"?"
});
