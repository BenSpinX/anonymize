DCM4CHE.elementName.addDictionary({
"privateCreator":"GEIIS_RA1000",
"0071xx01":"?",
"0071xx20":"?",
"0071xx21":"?",
"0071xx22":"?"
});
