DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS MR/PART 12",
"0009xx10":"?"
});
