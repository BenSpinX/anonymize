DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_ACRQA_2.0 BLOCK2",
"0023xx00":"CR S Shift",
"0023xx10":"CR C Shift",
"0023xx20":"CR GT",
"0023xx30":"CR GA",
"0023xx40":"CR GC",
"0023xx50":"CR GS",
"0023xx60":"CR RT",
"0023xx70":"CR RE",
"0023xx80":"CR RN",
"0023xx90":"CR DRT"
});
