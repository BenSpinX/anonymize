DCM4CHE.elementName.addDictionary({
"privateCreator":"GE LUT Asymmetry Parameter",
"0045xx67":"LUT Assymetry"
});
