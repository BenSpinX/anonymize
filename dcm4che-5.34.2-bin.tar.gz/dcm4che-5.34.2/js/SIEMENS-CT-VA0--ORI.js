DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT VA0  ORI",
"0009xx20":"?",
"0009xx30":"?"
});
