DCM4CHE.elementName.addDictionary({
"privateCreator":"http://www.gemedicalsystems.com/it_solutions/bamwallthickness/1.0",
"3118xx10":"BAM WallThickness Session Date/Time",
"3118xx20":"BAM WallThickness Session Creator",
"3118xx30":"BAM WallThickness Session Completion Flag",
"3118xx40":"BAM WallThickness File Sequence",
"3118xx50":"BAM WallThickness File Name",
"3118xx60":"BAM WallThickness File Content"
});
