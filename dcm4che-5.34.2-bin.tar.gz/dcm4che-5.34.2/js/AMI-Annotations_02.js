DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI Annotations_02",
"3101xx20":"Annotation Sequence"
});
