DCM4CHE.elementName.addDictionary({
"privateCreator":"MITRA MARKUP 1.0",
"0029xx00":"Markup1",
"0029xx01":"Markup2",
"0029xx02":"Markup3",
"0029xx03":"Markup4",
"0029xx04":"Markup5",
"0029xx05":"Markup6",
"0029xx06":"Markup7",
"0029xx07":"Markup8",
"0029xx08":"Markup9",
"0029xx09":"Markup10",
"0029xx10":"Markup11",
"0029xx11":"Markup12",
"0029xx12":"Markup13",
"0029xx13":"Markup14",
"0029xx14":"Markup15"
});
