DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS IKM CKS LUNGCAD BMK",
"0029xx01":"?"
});
