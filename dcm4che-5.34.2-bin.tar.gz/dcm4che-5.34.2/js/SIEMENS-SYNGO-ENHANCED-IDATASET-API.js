DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO ENHANCED IDATASET API",
"0027xx01":"Business Unit Code",
"0027xx02":"Application Type",
"0027xx03":"Application Attributes Sequenc"
});
