DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED DISPLAY 0001",
"0029xx99":"?",
"0029xxA0":"?",
"0029xxA1":"?",
"0029xxA2":"?"
});
