DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED",
"0009xx10":"Recognition Code",
"0009xx30":"Byte Offset of Original Header",
"0009xx31":"Length of Original Header",
"0009xx40":"Byte Offset of Pixelmatrix",
"0009xx41":"Length of Pixelmatrix In Bytes",
"0009xx50":"?",
"0009xx51":"?",
"0009xxF5":"PDM EFID Placeholder",
"0009xxF6":"PDM Data Object Type Extension",
"0021xx10":"Zoom",
"0021xx11":"Target",
"0021xx12":"Tube Angle",
"0021xx20":"ROI Mask",
"7001xx10":"Dummy",
"7003xx10":"Header"
});
