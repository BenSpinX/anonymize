DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_SERS_01",
"0025xx06":"Last Pulse Sequence Used",
"0025xx07":"Images In Series",
"0025xx10":"Landmark Counter",
"0025xx11":"Number Of Acquisitions",
"0025xx14":"Indicates Number Of Updates To Header",
"0025xx17":"Series Complete Flag",
"0025xx18":"Number Of Images Archived",
"0025xx19":"Last Instance Number Used",
"0025xx1A":"Primary Receiver Suite And Host",
"0025xx1B":"Protocol Data Block (compressed)"
});
