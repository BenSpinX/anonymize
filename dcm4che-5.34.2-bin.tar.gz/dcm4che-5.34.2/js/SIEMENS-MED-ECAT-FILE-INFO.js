DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED ECAT FILE INFO",
"0021xx00":"ECAT_Main_Header",
"0021xx01":"ECAT_Image_Subheader"
});
