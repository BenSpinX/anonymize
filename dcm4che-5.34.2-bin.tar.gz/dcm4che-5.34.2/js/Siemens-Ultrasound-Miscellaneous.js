DCM4CHE.elementName.addDictionary({
"privateCreator":"Siemens Ultrasound Miscellaneous",
"0019xx20":"?"
});
