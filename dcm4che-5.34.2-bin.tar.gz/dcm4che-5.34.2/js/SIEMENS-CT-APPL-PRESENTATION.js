DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT APPL PRESENTATION",
"0029xx00":"Translucent Mode",
"0029xx01":"Translucent Window Size",
"0029xx02":"Panoramic Mode",
"0029xx03":"Panoramic Inner Width",
"0029xx04":"Display Unseen Areas",
"0029xx05":"Unseen Areas Color",
"0029xx06":"Display Tagged Data",
"0029xx07":"Tagged Color",
"0029xx08":"Tagged Sample Thickness",
"0029xx09":"Tagged Threshold",
"0029xx10":"Kernel Filter"
});
