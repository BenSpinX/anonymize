DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO ENCAPSULATED DOCUMENT DATA",
"0087xx20":"Study Model",
"0087xx30":"Report XML Schema",
"0087xx40":"Report Identifier"
});
