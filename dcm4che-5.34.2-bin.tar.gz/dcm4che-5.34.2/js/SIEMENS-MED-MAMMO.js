DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MED MAMMO",
"0029xx5A":"?"
});
