DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS MEDCOM HEADER2",
"0029xx60":"Series Work Flow Statu"
});
