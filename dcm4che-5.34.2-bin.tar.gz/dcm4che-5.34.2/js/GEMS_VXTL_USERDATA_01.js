DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_VXTL_USERDATA_01",
"0047xx11":"?"
});
