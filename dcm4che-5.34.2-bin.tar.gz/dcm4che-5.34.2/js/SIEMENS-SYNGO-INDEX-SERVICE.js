DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS SYNGO INDEX SERVICE",
"0009xx20":"Object Insertion Date",
"0009xxA0":"Sender System Device Name",
"0009xx40":"Last Access Time",
"0009xx41":"Delete Protected Status",
"0009xx42":"Received from Archive Status",
"0009xx43":"Archive Status",
"0009xx44":"Location",
"0009xx45":"Logical Deleted Status",
"0009xx46":"Insert Time",
"0009xx47":"Visible Instances on Series Level",
"0009xx48":"Unarchived Instances",
"0009xx49":"Visible Instances on Study Level",
"0009xx31":"Series Object States",
"0009xx30":"Instance Object States",
"0009xx50":"Hidden Instance"
});
