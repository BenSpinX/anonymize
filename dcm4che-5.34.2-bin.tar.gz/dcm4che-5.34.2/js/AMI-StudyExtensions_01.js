DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI StudyExtensions_01",
"3111xx01":"Last Released Annot Label"
});
