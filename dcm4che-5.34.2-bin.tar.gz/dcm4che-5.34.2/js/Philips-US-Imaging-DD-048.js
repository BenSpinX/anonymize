DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips US Imaging DD 048",
"200Dxx01":"?"
});
