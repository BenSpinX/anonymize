DCM4CHE.elementName.addDictionary({
"privateCreator":"PHILIPS MR/PART 7",
"0019xx00":"?"
});
