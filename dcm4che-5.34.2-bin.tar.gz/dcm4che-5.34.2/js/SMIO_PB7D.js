DCM4CHE.elementName.addDictionary({
"privateCreator":"SMIO_PB7D",
"007Dxx01":"Geometry",
"007Dxx02":"Spacing",
"007Dxx03":"Origin"
});
