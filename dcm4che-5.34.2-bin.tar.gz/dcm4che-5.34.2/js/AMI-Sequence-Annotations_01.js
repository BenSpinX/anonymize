DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI Sequence Annotations_01",
"3103xx10":"Annotation Sequence",
"3103xx20":"Annotation UID",
"3103xx30":"Annotation Color",
"3103xx50":"Annotation Line Style",
"3103xx60":"Annotation Elements",
"3103xx70":"Annotation Label",
"3103xx80":"Annotation Creator",
"3103xx90":"Annotation Modifiers",
"3103xxA0":"Annotation Creation Date",
"3103xxB0":"Annotation Creation Time",
"3103xxC0":"Annotation Modification Dates",
"3103xxD0":"Annotation Mofification Times",
"3103xxE0":"Annotation Frame Number"
});
