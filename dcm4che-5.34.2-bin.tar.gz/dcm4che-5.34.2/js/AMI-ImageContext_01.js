DCM4CHE.elementName.addDictionary({
"privateCreator":"AMI ImageContext_01",
"3109xx10":"Window Invert",
"3109xx20":"Window Center",
"3109xx30":"Window Width",
"3109xx40":"Pixel Aspect Ratio Swap",
"3109xx50":"Enable Averaging",
"3109xx60":"Quality",
"3109xx70":"Viewport Annotation Level",
"3109xx80":"Show Image Annotation",
"3109xx90":"Show Image Overlay"
});
