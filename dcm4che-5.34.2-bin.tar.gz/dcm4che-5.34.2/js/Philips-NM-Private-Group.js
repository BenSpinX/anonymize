DCM4CHE.elementName.addDictionary({
"privateCreator":"Philips NM Private Group",
"7043xx00":"?"
});
