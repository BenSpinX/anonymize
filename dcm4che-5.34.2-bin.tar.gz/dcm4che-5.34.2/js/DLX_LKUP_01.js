DCM4CHE.elementName.addDictionary({
"privateCreator":"DLX_LKUP_01",
"60XXxx01":"Gray Palette Color Lookup Table Descriptor",
"60XXxx02":"Gray Palette Color Lookup Table Data"
});
