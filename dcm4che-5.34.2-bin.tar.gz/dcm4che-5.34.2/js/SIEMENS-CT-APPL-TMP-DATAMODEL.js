DCM4CHE.elementName.addDictionary({
"privateCreator":"SIEMENS CT APPL TMP DATAMODEL",
"0029xx00":"CT Task Common DataModel"
});
