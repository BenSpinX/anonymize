DCM4CHE.elementName.addDictionary({
"privateCreator":"SPI-P-CTBE Release 1",
"0019xx00":"?",
"0019xx02":"?",
"0019xx03":"?",
"0019xx04":"?",
"0019xx05":"?",
"0019xx0B":"?",
"0019xx0C":"?",
"0019xx14":"?",
"0019xx18":"?",
"0019xx19":"?",
"0019xx1A":"?",
"0019xx1B":"?",
"0019xx1C":"?",
"0019xx1D":"?"
});
