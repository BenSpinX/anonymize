DCM4CHE.elementName.addDictionary({
"privateCreator":"GEMS_LUNAR_RAW",
"7003xx01":"enCORE File Name",
"7003xx02":"enCORE File Data",
"7003xx03":"enCORE File Length",
"7003xx04":"enCORE File Modified Time"
});
